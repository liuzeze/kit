package lz.com.kit.widget.recycleview;


import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.recyclerview.widget.RecyclerView;


/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2018-12-16        越界回弹
 */
public class ReboundReyclerView extends RecyclerView {

    //移动百分比
    private static final float MOVE_FACTOR = 0.5f;

    //松开手指后, 界面回到正常位置需要的动画时间
    private static final int ANIM_TIME = 300;

    //手指按下时的Y值, 用于在移动时计算移动距离
    private float startY;


    //手指按下时记录是否可以继续下拉
    private boolean canPullDown = false;
    //手指按下时记录是否可以继续上拉
    private boolean canPullUp = false;
    private boolean isCanPullUp = true;

    //在手指滑动的过程中记录是否移动了布局
    private boolean isMoved = false;
    private CustomizeLinearLayoutManager mLayout;

    public ReboundReyclerView(Context context) {
        super(context);
    }

    public ReboundReyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ReboundReyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                //判断是否可以下拉 上拉
                canPullDown = !canScrollVertically(-1);
                canPullUp = !canScrollVertically(1) && isCanPullUp;
                //记录按下时的Y值
                startY = ev.getY();
                break;
            case MotionEvent.ACTION_UP:
                //如果没有移动布局， 则跳过执行
                if (!isMoved) {
                    break;
                }
                final float translationY = getTranslationY();
                // 开启动画
                animate().translationY(0)
                        .setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                if ((translationY < 0)) {
                                    if (mOnUpScrollListener != null) {
                                        mOnUpScrollListener.onUpScroll((int) translationY);
                                    }
                                }
                            }
                        }).setDuration(ANIM_TIME).start();
                //将标志位设回false
                canPullDown = false;
                canPullUp = false;
                isMoved = false;
                setEnableScroll(true);
                break;
            case MotionEvent.ACTION_MOVE:

                //在移动的过程中， 也没有滚动到可以下拉的程度
                if (!canPullDown && !canPullUp) {
                    startY = ev.getY();
                    canPullDown = !canScrollVertically(-1);
                    canPullUp = !canScrollVertically(1) && isCanPullUp;
                    break;
                }
                //计算手指移动的距离
                float nowY = ev.getY();
                int deltaY = (int) (nowY - startY);

                //是否应该移动布局
                boolean shouldMove =
                        //可以下拉， 并且手指向下移动
                        (canPullDown && deltaY > 0)
                                //可以上拉， 并且手指向上移动
                                || (canPullUp && deltaY < 0)
                                //既可以上拉也可以下拉（这种情况出现在ScrollView包裹的控件比ScrollView还小）
                                || (canPullUp && canPullDown);
                if (shouldMove) {
                    //计算偏移量
                    int offset = (int) (deltaY * MOVE_FACTOR);
                    //随着手指的移动而移动布局
                    setTranslationY(offset);
                    //记录移动了布局
                    isMoved = true;
                    setEnableScroll(false);
                    if ((canPullUp && deltaY < 0)) {
                        if (mOnUpScrollListener != null) {
                            mOnUpScrollListener.onUpMoveScroll(offset);
                        }
                    }

                }
                break;
            default:
                break;
        }

        return super.dispatchTouchEvent(ev);
    }

    private void setEnableScroll(boolean isEnableScroll) {
        if (mLayout != null) {
            mLayout.setScrollEnabled(isEnableScroll);
        }
    }

    public ReboundReyclerView setCanPullUp(boolean canPullUp) {
        isCanPullUp = canPullUp;
        return this;
    }

    private OnUpScrollListener mOnUpScrollListener;

    public interface OnUpScrollListener {
        void onUpScroll(int offset);

        void onUpMoveScroll(int offset);
    }

    public void setOnUpScrollListener(OnUpScrollListener onUpScrollListener) {
        mOnUpScrollListener = onUpScrollListener;
    }

    public void setLayoutManager(CustomizeLinearLayoutManager layout) {
        super.setLayoutManager(layout);
        mLayout = layout;
    }
}
