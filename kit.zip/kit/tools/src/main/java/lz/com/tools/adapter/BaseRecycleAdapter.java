package lz.com.kit.widget.adapter;

import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2019-01-11       基类adapter
 */
public class BaseRecycleAdapter<T, K extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<K> {


    private List<T> mData;
    private int mLayoutResId;

    public BaseRecycleAdapter(@LayoutRes int layoutResId, @Nullable List<T> data) {
        this.mData = data == null ? new ArrayList<T>() : data;
        if (layoutResId != 0) {
            this.mLayoutResId = layoutResId;
        }
    }

    @NonNull
    @Override
    public K onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull K holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
